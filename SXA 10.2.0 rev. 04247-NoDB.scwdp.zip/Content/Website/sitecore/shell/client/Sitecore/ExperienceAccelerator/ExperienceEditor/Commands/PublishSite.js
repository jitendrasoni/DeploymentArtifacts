﻿define(["sitecore", "/-/speak/v1/ExperienceEditor/ExperienceEditor.js"], function (Sitecore, ExperienceEditor) {
    Sitecore.Commands.PublishSite =
    {
        canExecute: function (context) {
            return true;
        },
        execute: function (context) {
            var self = this;
            ExperienceEditor.modifiedHandling(true, function () {
                var requestContext = context.app.clone(context.currentContext);
                requestContext.target = "$site";
                ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.XA.CheckWorkflow", function (response) {
                    var id = response.responseValue.value;

                    if (!id) {
                         return;
                    }

                    var result = self.getItemAncestorsPublishingStatus(requestContext, context);

                    if (result.status) {
                        self.showPublishDialog(id);
                    } else {
                        self.showItemPublishConfirmation(result.message, function(isUserConfirmed) {
                            if (isUserConfirmed) {
                                self.showPublishDialog(id);
                            }
                        });
                    }

                }, requestContext).execute(context);
            });
        },
        showPublishDialog: function(id) {
            var dialogPath = "/sitecore/shell/Applications/Publish.aspx?id=" + id,
                dialogFeatures = "dialogHeight: 600px;dialogWidth: 500px;";
            ExperienceEditor.Dialogs.showModalDialog(dialogPath, '', dialogFeatures);
        },
        getItemAncestorsPublishingStatus: function(requestContext, context) {
            var result;

            ExperienceEditor.PipelinesUtil.generateRequestProcessor(
                "ExperienceEditor.XA.GetItemAncestorsPublishingStatus", function(getAllPublishingTargetsResponse) {
                    result = getAllPublishingTargetsResponse.responseValue.value;
                }, requestContext).execute(context);

            return result;
        },
        showItemPublishConfirmation: function(message, confirmationCallback) {
            ExperienceEditor.Dialogs.confirm(message, confirmationCallback);
        }
    };
});