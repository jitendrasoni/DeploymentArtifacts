﻿define(
  [
    "sitecore"
  ],
  function () {
      var presentation = {
      };
      presentation.templates = {
          PartialDesign: "{642BDD94-EED5-4B51-B27C-C9543FAB663F}",
          _DesignTemplateMapping: "{71B1F3CD-4460-430F-82EC-9CE310ABCB7C}",
          PageDesign: "{0407560F-387B-4A90-ADBE-398B077890E9}"
      }
      return presentation;
  });