﻿function SxaEditor() {
}

SxaEditor.prototype.initialize = function () {
    this.attachEvents();
}

SxaEditor.prototype.attachEvents = function () {
    Event.observe(window, "load", function () {
        document.observe("sc:contenttreeupdated", function (e) {
            this.refreshMediaItem(e);
        }.bindAsEventListener(this));
    }.bind(this));
}

SxaEditor.prototype.refreshMediaItem = function (e) {
    var treeNodes = document.getElementsByClassName("scContentTreeNode"),
        mediaItemId,
        node,
        i;

    for (i = 0; i < treeNodes.length; i++) {
        node = treeNodes[i];
        if (node.textContent === "Media" && node.innerHTML.indexOf("noexpand15x15") !== -1) {
            mediaItemId = this.getMediaItemId(node);
            if (mediaItemId !== null) {
                scForm.postEvent(this, e, 'Tree_Refresh("{' + mediaItemId + '}")');
                while (node.childNodes.length > 3) {
                    node.removeChild(node.childNodes[3]);
                }
                scForm.browser.setOuterHtml(node.childNodes[0], scForm.browser.getOuterHtml(node.childNodes[0]).replace("/treemenu_expanded.png", "/treemenu_collapsed.png"));
            }
        }
    }
}

SxaEditor.prototype.getMediaItemId = function (node) {
    var gutters = node.getElementsByClassName("scContentTreeNodeGutter"),
        gutter,
        id;
    if (gutters.length > 0) {
        gutter = gutters[0];
        return gutter.id.replace("Gutter", "").replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, "$1-$2-$3-$4-$5");
    }
    return null;
}

var sxaEditor = new SxaEditor();
sxaEditor.initialize();