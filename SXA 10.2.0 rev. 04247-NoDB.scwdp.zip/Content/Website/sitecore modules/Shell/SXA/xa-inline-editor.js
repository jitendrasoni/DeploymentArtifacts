﻿const InlineEditorPropertiesEditorContract = {
    name: 'properties-editor',
};
const hrzRenderingChromeUtilsContract = {
    name: 'renderingChrome-utils',
};

function getFilter() {
    return window.getComputedStyle(document.body, ':before').content ? window.getComputedStyle(document.body, ':before').content.replace(/\"/g, '') : "";
}

function StateClass() {
    var state = {
        reload: false,
        message: ''
    }
    return {
        setState: function (newState) {
            state = newState;
        },
        getState: function () {
            return state;
        }

    }
}
window.xaStateClass = new StateClass();
window.xaInlineEditor = async ({ startElement, messaging }) => {
    const stateClass = window.xaStateClass;
    const codeValue = JSON.parse(startElement.innerHTML).custom;
    const renderingId = codeValue.renderingId ? codeValue.renderingId : "";
    const renderingInstanceId = codeValue.renderingInstanceId ? codeValue.renderingInstanceId.replace("{", "").replace("}", "") : "";
    const propEvents = messaging.getEventReceiver(InlineEditorPropertiesEditorContract);
    const propRpc = await messaging.getRpc(InlineEditorPropertiesEditorContract);
    const hrzRenderingChromeUtilsRpc = await messaging.getRpc(
        hrzRenderingChromeUtilsContract
    );
    const htmlElement = getNextElementComponent();
    const gridLayout = getGrid();
    let timeout;

    function getNextElementComponent() {
        let nextSibilingComponent = startElement.nextElementSibling;
        while (nextSibilingComponent) {
            if (
                nextSibilingComponent.nodeType === Node.ELEMENT_NODE
                && nextSibilingComponent.classList.contains('component')
            ) {
                nextSibilingComponent = nextSibilingComponent;
                break;
            }
            nextSibilingComponent = nextSibilingComponent.nextSibling;
        }
        return nextSibilingComponent;
    }

    function setStyle(styles) {
        let prevVal = styles.prevValue,
            value = styles.value;
        if (styles.sectionName === "advanced-styling") {
            return;
        }
        if (prevVal.length > 0) {
            prevVal.split(' ').forEach(el => {
                htmlElement.classList.remove(el);
            })

        }
        if (value.length > 0) {
            value.split(' ').forEach(el => {
                htmlElement.classList.add(el);
            })

        }
        hrzRenderingChromeUtilsRpc.notifyResize();
    };

    function getGrid() {
        return JSON.parse(document.querySelector('#xa-hrz-canvas-grid').innerHTML);
    }
    window.addEventListener("resize", resizeThrottler, false);

    function sendLayoutData() {
        var layoutData = {
            reloadNeeded: stateClass.getState(),
            grid: gridLayout,
            renderingId: renderingId,
            renderingInstanceId: renderingInstanceId,
            filter: getFilter()
        }
        propRpc.postPropertiesEditorMessage(layoutData);
    }

    function resizeThrottler() {
        // clear the timeout
        clearTimeout(timeout);
        // start timing for event "completion"
        timeout = setTimeout(sendLayoutData, 500);
    }

    function reloadCanvas() {
        window.location.reload();
    }
    function reloadNeeded(message) {
        stateClass.setState({
            reload: true,
            message: message
        })
    }
    propEvents.on('onPropertiesEditorMessage', (details) => {
        if (details.action === "getData") {
            sendLayoutData();
        } else if (details.action === "reloadNeeded") {
            reloadNeeded(details.data);
        } else if (details.action === "reloadCanvas") {
            reloadCanvas();
        } else {
            setStyle(details.data)
        }
    });

    return {
        editorProtocols: ['xa-orchestrator'],
    };
};